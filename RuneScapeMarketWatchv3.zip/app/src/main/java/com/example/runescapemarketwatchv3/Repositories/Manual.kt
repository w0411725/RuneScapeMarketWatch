//val newArticle = MarketNews(
//    id = 4,
//    title = "Major Patch Update",
//    type = "Patch Notes",
//    date = "2024-12-10",
//    description = "A major patch has been released, introducing several changes to gameplay."
//)
//
//// Add the new article to the repository
//viewModel.addNews(newArticle)

        //MANUAL INCLUSION OF NEWS